C:\Program Files\Tesseract-OCR\tesseract.exe

Need to install OCR software in this folder. 